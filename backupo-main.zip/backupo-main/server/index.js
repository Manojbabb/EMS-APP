 
const express = require("express");
const oracledb = require("oracledb");
const cors = require("cors");
const jwt = require("jsonwebtoken");
// const { FaTrophy } = require("react-icons/fa");
  
const app = express();
app.use(express.json());
app.use(cors());

const corsOptions = {
  origin: ['http://localhost:3000', 'http://localhost:3015'],
  credentials: true,
};
app.use(cors(corsOptions));

async function connectDB() {
  let connection;
  try {
    connection = await oracledb.getConnection({
      user: "custom",
      password: "custom",
      connectString: "dbfin:1521/FINMULTI",
      port: 1521
    });
    console.log("Successfully connected to Oracle Database");
    return connection;
  } catch (err) {
    console.error("Error connecting to Oracle Database:", err);
    throw err;
  }
}
//const jwt = require('jsonwebtoken');  

app.post('/sign', async (req, res) => {
  let connection; 
  try {
    connection = await connectDB(); 
    const { emp_name, mobile, department, emp_email, password, emp_address, emp_designation, Rolead } = req.body; 
    const insert = "INSERT INTO custom.login (emp_name, mobile, department, emp_email, password, emp_address, emp_designation, Rolead) VALUES (:emp_name, :mobile, :department, :emp_email, :password, :emp_address, :emp_designation, :Rolead)";
    const binds = { emp_name, mobile, department, emp_email, password, emp_address, emp_designation, Rolead }; 
    await connection.execute(insert, binds, { autoCommit: true }); 
    res.send("User registered successfully");
  } catch (err) {
    console.error("Error inserting user:", err);
    res.status(500).send({ message: "An error occurred while registering the user." });
  }
});
 
app.post("/server", async (req, res) => {
  let connection; 
  try {
    connection = await connectDB(); 
    const { emp_email, password,Rolead } = req.body; 
    const select = "SELECT * FROM custom.login WHERE emp_email = :emp_email AND password = :password AND Rolead =:Rolead";
    const selectParams = { emp_email, password, Rolead }; 
    const result = await connection.execute(select, selectParams); 
    if (result.rows.length > 0) {
      const user = result.rows[0];
      const { emp_email, Rolead } = user; 
      const token = jwt.sign({ emp_email, Rolead }, ' eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE3MTkyMjEzMzksImV4cCI6MTcxOTIyNDkzOX0.yvqPuG1jxnvNefWWU8QveREnlAKVo8BUMWaeDaGY5PQ', { expiresIn: '1h' });
     res.json({ message: "Login successful", token, role: Rolead });
    } else {
      res.status(401).send({ message: "Invalid email or password" });
    } 
  } catch (err) {
    console.error('Error executing query:', err);
    res.status(500).send({ message: "An error occurred while logging in." });
  }
});  

app.post("/protect", async (req, res) => {
  let connection;
  try {
    connection = await connectDB();
    const { Rolead } = req.body;
    const select = "SELECT * FROM custom.login WHERE Rolead = :Rolead";
    const selectParams = { Rolead };
    const result = await connection.execute(select, selectParams);
    
    if (result.rows.length > 0) {
      const user = result.rows[0];
      const { Rolead } = user; 
      const token = jwt.sign({ Rolead }, 'your_secret_key', { expiresIn: '1h' });
      
      res.json({ message: "Auth successful", token, role: Rolead });
    } else {
      res.status(401).send({ message: "Invalid role or unauthorized" });
    }
  } catch (err) {
    console.error('Error executing query:', err);
    res.status(500).send({ message: "An error occurred while logging in." });
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error("Error closing connection:", err);
      }
    }
  }
});
  
// const authenticateJWT = (req, res, next) => {
//   const token = req.headers.authorization && req.headers.authorization.split(' ')[1];
//   if (token) {
//     jwt.verify(token, '03f867b7e0c8a6d57033b1de49808a870120acad3429d940ecad412123f646b1b567f49b6bee71b00bbfc6f688da6596bce838843da8b061dab9f61c56da8e18', (err, user) => {
//       if (err) {
//         return res.sendStatus(403);
//       }
//       req.user = user;
//       next();
//     });
//   } else {
//     res.sendStatus(401);
//   }
// };

// app.get('/profile', authenticateJWT, async (req, res) => {
//   let connection;
//   try {
//     connection = await connectDB();
//     const emp_email = req.user.emp_email; 
//     const query = "SELECT emp_name, mobile, department, emp_email, emp_address, emp_designation FROM custom.login WHERE emp_email = :emp_email";
//     const result = await connection.execute(query, { emp_email });
//     if (result.rows.length > 0) {
//       const user = result.rows[0];
//       const profile = {
//         emp_name: user.EMP_NAME,
//         mobile: user.MOBILE,
//         department: user.DEPARTMENT,
//         emp_email: user.EMP_EMAIL,
//         emp_address: user.EMP_ADDRESS,
//         emp_designation: user.EMP_DESIGNATION
//       };
//       res.json({ profile})
//       console.log(profile)
//     } else {
//       res.status(404).send({ message: "User not found" });
//     }
//   } catch (err) {
//     console.error('Error fetching user profile:', err);
//     res.status(500).send({ message: "An error occurred while fetching user profile." });
//   } finally {
//     if (connection) {
//       try {
//         await connection.close();
//       } catch (err) {
//         console.error("Error closing connection:", err);
//       }
//     }
//   }
// });
// app.use((req, res, next) => {
//   // Mock user for testing (Replace with your actual authentication logic)
//   req.user = { emp_email :'admin@gmail.com'};
//   next();
// });

// app.get('/profile', authenticateJWT,async (req, res) => {
//   let connection;

//   try {
//     connection = await connectDB();
//     const emp_email = req.user.emp_email;   
//     if (!emp_email) {
//       return res.status(400).send({ message: "Email is required for profile lookup" });
//     } 
//     const query = "SELECT emp_name, mobile, department, emp_email, emp_address, emp_designation FROM custom.login WHERE emp_email = :emp_email";
//     const result = await connection.execute(query, { emp_email }); 
//     console.log('Query Result:', result);  
//     if (result.rows.length > 0) { 
//       const user = result.rows[0];
//       const profile = {
//         emp_name: user[0],  
//         mobile: user[1],
//         department: user[2],
//         emp_email: user[3],
//         emp_address: user[4],
//         emp_designation: user[5]
//       }; 
//       res.json({ profile });
//       console.log(profile);
//     } else {
//       res.status(404).send({ message: "User not found" });
//     }
//   } catch (err) {
//     console.error('Error fetching user profile:', err);
//     res.status(500).send({ message: "An error occurred while fetching user profile." });
//   } finally {
//     if (connection) {
//       try {
//         await connection.close();
//       } catch (err) {
//         console.error("Error closing connection:", err);
//       }
//     }
//   }
// });


// app.post('/eventinsert' , async(req,res)=>{
//   let connection;
//   try{
//     connection = await connectDB();
//     const {eventn,eventemail,selectevent,describeevent,eventdat,eventtime} =req.body;
//     const insertMain = "INSERT INTO custom.eventmap (eventn,eventemail,selectevent,describeevent,eventdat,eventtime) VALUES ( :eventn, :eventemail, :selectevent, :describeevent, :eventdat, :eventtime)"
//     const bind = {eventn,eventemail,selectevent,describeevent,eventdat,eventtime}
//     await connection.execute(insertMain,bind,{autoCommmit: true});
//     res.send("User leave applied successfully");
//   } catch (err) {
//     console.error("Error inserting user:", err);
//     res.status(500).send({ message: "An error occurred while applying for leave."});
//   }
// })
 
app.post('/eventinsert', async (req, res) => {
  let connection;
  try {
    connection = await connectDB();
    const {eventn,eventemail,selectevent,describeevent, eventdat,eventtime} = req.body;
    const inserted = "INSERT INTO  custom.eventmap (eventn,eventemail,selectevent,describeevent, eventdat,eventtime) VALUES (:eventn, :eventemail, :selectevent, :describeevent, :eventdat, :eventtime)";
    const bind = {eventn,eventemail,selectevent,describeevent, eventdat,eventtime};
    await connection.execute(inserted, bind, { autoCommit: true });
    res.send("User event stored successfully");
  } catch (err) {
    console.error("Error inserting user:", err);
    res.status(500).send({ message: "An error occurred while applying for leave."});
  }
}); 
app.delete('/eventdelete/:id', async (req, res) => {
  let connection;
  try {
    const id = req.params.id; // Retrieve the ID from the request parameters

    // Establish a database connection
    connection = await connectDB();

    const delQuery = 'DELETE FROM custom.eventmap WHERE id = :id'; 
    const result = await connection.execute(delQuery, { id }, { autoCommit: true });

    // Send a success response
    res.status(200).send("Data deleted successfully");
    console.log('Data deleted:', result.rowsAffected);

  } catch (err) {
    console.error('Error executing query:', err);
    res.status(500).send('Error deleting data');
  } finally {
    if (connection) {
      try {
        await connection.close();
        console.log('Connection closed successfully');
      } catch (err) {
        console.error('Error closing connection:', err);
      }
    }
  }
});
 
app.get('/displayevent', async(req,res)=>{
  let connection;
  try{
    connection = await connectDB();
    const select = "SELECT * FROM custom.eventmap";
    const result = await connection.execute(select);
    const event = result.rows.map((row) => { 
      return {
        id: row[0], 
        eventn: row[1],
        eventemail: row[2],
        selectevent: row[3],
        describeevent: row[4],
        eventdat: row[5] ,
        eventtime: row[6] 
      };
    });
    res.json({event: event});
    } catch (err) {
      console.error('Error executing query:', err);
      res.status(500).send({ message: "An error occurred while displaying events." });
      }  
  })
 
const verifyToken = (req, res, next) => {
  const tokenHeader = req.headers.authorization;
  if (!tokenHeader || !tokenHeader.startsWith("Bearer ")) {
    return res.status(403).send("Token is missing or invalid!");
  }
  const token = tokenHeader.replace("Bearer ", "");
  try {
    const verified = jwt.verify(token, '03f867b7e0c8a6d57033b1de49808a870120acad3429d940ecad412123f646b1b567f49b6bee71b00bbfc6f688da6596bce838843da8b061dab9f61c56da8e18');
    req.user = verified;
    next();
  } catch (err) {
    res.status(401).send("Invalid Token");
  }
}; 
app.get('/protected', verifyToken, (req, res) => {
  res.send("This is a protected route");
});  
app.post('/unland', async (req, res) => {
  let connection;
  try {
    connection = await connectDB();
    const { leave_type, employee_id, start_date, end_date, lev_reason, lev_approve } = req.body;
    const inserted = "INSERT INTO custom.leave (leave_type, employee_id, start_date, end_date, lev_reason, lev_approve) VALUES (:leave_type, :employee_id, :start_date, :end_date, :lev_reason, :lev_approve)";
    const bind = {leave_type, employee_id, start_date, end_date, lev_reason, lev_approve };
    await connection.execute(inserted, bind, { autoCommit: true });
    res.send("User leave applied successfully");
  } catch (err) {
    console.error("Error inserting user:", err);
    res.status(500).send({ message: "An error occurred while applying for leave."});
  }
}); 
 
app.post('/attend', async (req, res) => {
  let connection;
  try {
    connection = await connectDB();
    const { employee_id, employee, checki,  checko } = req.body;
    const inserted = "INSERT INTO custom.atten (employee_id, employee, checki,  checko) VALUES (:employee_id, :employee, :checki,  :checko)";
    const bind = { employee_id, employee, checki,  checko };
    await connection.execute(inserted, bind, { autoCommit: true });
    res.send("User leave applied successfully");
  } catch (err) {
    console.error("Error inserting user:", err);
    res.status(500).send({ message: "An error occurred while applying for leave."});
  }
}); 
app.get('/getting', async (_req, res) => {
  let connection;
  try {
    connection = await connectDB();
    const sqlQuery = 'SELECT * FROM custom.atten';
    const result = await connection.execute(sqlQuery);
    const attendance = result.rows.map((row) => { 
      return {
        id: row[0], 
        employee_id: row[1],
        employee: row[2],
        checki: row[3],
        checko: row[4] 
      };
    });
    console.log(attendance); 
    res.json({ attendance: attendance });
  } catch (err) {
    console.error("Error:", err.message);
    res.status(500).send('Internal Server Error');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error("Error closing the database connection:", err.message);
      }
    }
  }
}); 
app.get('/onsite', async (_req, res) => {
  let connection;
  try {
    connection = await connectDB();
    const query = "SELECT COUNT(*) AS onsiteCount FROM custom.atten WHERE employee='Onsite employee'";
    const result = await connection.execute(query);
    const onsiteCount = result.rows[0][0]; 
    res.json({  onsitee: [{ onsiteCount }] }); 
    console.log("Onsite employee Count :", onsiteCount);
  } catch (err) {
    console.error("Error counting male employees:", err);
    res.status(500).send({ message: "An error occurred while counting male employees." });
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error("Error closing the database connection:", err.message);
      }
    }
  }
});
app.get('/present', async (_req, res) => {
  let connection;
  try {
    connection = await connectDB();
    const query = "SELECT COUNT(DISTINCT  employee_id) AS presentCount FROM custom.atten";
    const result = await connection.execute(query);
    const presentCount = result.rows[0][0];   
    res.json({  sending: [{ presentCount }] }); 
    console.log("Present count :", presentCount);
  } catch (err) {
    console.error("Error counting male employees:", err);
    res.status(500).send({ message: "An error occurred while counting male employees." });
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error("Error closing the database connection:", err.message);
      }
    }
  }
}); 

// app.get('/empdata', async (req, res) => {
//   let connection; 
//   try {
//     connection=await connectDB(); 
//     const sql = "SELECT * FROM custom.employee"; 
//     const result = await connection.execute(sql); 
//    const modify  = result.rows.map((row) => 
//     {
//       return{
//       id:row[0],
//       employee_name:row[1],
//       father_name:row[2],
//       employee_id:row[3],
//       personal_email:row[4],
//       work_email:row[5],
//       mobile:row[6], 
//       gender:row[7],
//       dob:row[8],
//       marital_status:row[9],
//       location:row[10],
//       permanent:row[11],
//       employee_Ref:row[12],
//       remark:row[13],
//       department:row[14],
//       designation:row[15],
//       reporting:row[16],
//       pan_no:row[17],
//       aadhar:row[18],
//       bankac:row[19],
//       bankName:row[20],
//       uanno:row[21],
//       pfno:row[22],
//       blood_G:row[23],
//       startjoin:row[24] 
//     }
//   }) 
//  console.log(modify.rows);
//   res.json({ modify: modify.rows}); 
//   } catch (err) {
//     console.error('Error executing query:', err);
//     res.status(500).send('Error fetching data');
//   } finally {
//     if (connection) {
//       try {
//         await connection.close();
//       } catch (err) {
//         console.error('Error closing connection:', err);
//       }
//     }
//   }
// });
 

// app.get('/setting/:id', async (req, res) => {
//   let connection;
//   try {
//     connection = await connectDB();
//     const id = req.params.id;  
//     const sqlQuery = 'SELECT * FROM custom.employee WHERE id = :id';  
//     const result = await connection.execute(sqlQuery, [id]); 
//     const details = result.rows.map((row) => { 
//       return {
//         id: row[0], 
//         employee_name: row[1],
//         designation: row[15],
//         employee_id: row[3],
//         work_email: row[5],
//         mobile: row[6],
//         reporting: row[16],
//         startjoin: row[23],
//         permanent: row[11]
//       };
//     });
    
//     if (details.length === 0) {
//       console.log('No data found for the given ID.');
//       res.status(404).send('No data found');
//     } else {
//       console.log(details); 
//       res.json({ details: details[0] });  
//     }
//   } catch (err) {
//     console.error("Error:", err.message);
//     res.status(500).send('Internal Server Error');
//   } finally {
//     if (connection) {
//       try {
//         await connection.close();
//       } catch (err) {
//         console.error("Error closing the database connection:", err.message);
//       }
//     }
//   }
// });


//  app.get('/empdata/:id', async (req, res) => {
//   let connection; 
//   try {
//     connection = await connectDB();
//     const { id } = req.params;  
//     const code = "SELECT * FROM employee WHERE id = ?";   
//     const result = await connection.execute(code, [id]);
    
//     const users = result.rows.map((row) => {
//       return {
//         id: row[0],
//         employee_name: row[1],
//         father_name: row[2],
//         employee_id: row[3],
//         personal_email: row[4],
//         work_email: row[5],
//         mobile: row[6],
//         gender: row[7],
//         dob: row[8],
//         marital_status: row[9],
//         location: row[10],
//         permanent: row[11],
//         employee_Ref: row[12],
//         remark: row[13],
//         department: row[14],
//         designation: row[15],
//         reporting: row[16],
//         pan_no: row[17],
//         aadhar: row[18],
//         bankac: row[19],
//         bankName: row[20],
//         uanno: row[21],
//         pfno: row[22],
//         blood_G: row[23],
//         startjoin: row[24]
//       };
//     });

//     console.log(users);
//     res.json({ users: users });
//   } catch (err) {
//     console.error('Error executing query:', err);
//     res.status(500).send('Error fetching data');
//   } finally {
//     if (connection) {
//       try {
//         await connection.close();
//       } catch (err) {
//         console.error('Error closing connection:', err);
//       }
//     }
//   }
// });

app.put('/empupdate/:id', async (req, res) => {
  let connection;
  try {
    const id = req.params.id;
    const { employee_name, father_name, employee_id, personal_email, work_mail, mobile, bankac, bankName, gender} = req.body;
    connection = await connectDB();
    const update = `UPDATE custom.employee SET employee_name = :employee_name, father_name = :father_name, employee_id = :employee_id, personal_email = :personal_email, work_mail = :work_mail, mobile = :mobile, bankac = :bankac, bankName = :bankName, gender = :gender WHERE id = :id`;
    const params = { id, employee_name, father_name, employee_id, personal_email, work_mail, mobile, bankac, bankName, gender   };
    const result = await connection.execute(update, params, { autoCommit: true });
    res.send("Data updated successfully");
    console.log(result);
  } catch (err) {
    console.error('Error executing query:', err);
    res.status(500).send('Error updating data');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error('Error closing connection:', err);
      }
    }
  }
}); 
app.put('/update/:id', async (req, res) => {
  let connection;
  try {
    const id = req.params.id;
    const newStatus = req.body.newStatus; 
    connection = await connectDB();
    const update = 'UPDATE custom.leave SET lev_status = :newStatus WHERE id = :id'; 
    const code = { newStatus, id: id }; // Use appropriate parameter names
    const result = await connection.execute(update, code, { autoCommit: true });
    res.send("Data updated successfully");
    console.log(result)
  } catch (err) {
    console.error('Error executing query:', err);
    res.status(500).send('Error updating data');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error('Error closing connection:', err);
      }
    }
  }
});


app.delete('/delete/:id', async (req, res) => {
  let connection;
  try {
    const id = req.params.id;  
    connection = await connectDB(); 
    const selectQuery = 'SELECT * FROM custom.leave WHERE id = :id';
    const selectedData = await connection.execute(selectQuery, { id }, { outFormat: connection.OBJECT }); 
    const archiveQuery = 'INSERT INTO custom.leave_archive SELECT * FROM custom.leave WHERE id = :id';
    await connection.execute(archiveQuery, { id }, { autoCommit: false }); 
    const delQuery = 'DELETE FROM custom.leave WHERE id = :id'; 
    await connection.execute(delQuery, { id }, { autoCommit: false }); 
    await connection.commit(); 
    res.send("Data archived and deleted successfully");
  } catch (err) {
    console.error('Error executing query:', err);
    res.status(500).send('Error processing request'); 
    if (connection) {
      await connection.rollback();
    }
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error('Error closing connection:', err);
      }
    }
  }
});
// app.delete('/delete/:id', async (req, res) => {
//   let connection;
//   try {
//     const id = req.params.id; // Retrieve the ID from the request parameters
//     connection = await connectDB();
//     const delQuery = 'DELETE FROM custom.leave WHERE id = :id'; 
//     const result = await connection.execute(delQuery, { id }, { autoCommit: true });
//     res.send("Data deleted successfully");
//     console.log(result);
//   } catch (err) {
//     console.error('Error executing query:', err);
//     res.status(500).send('Error deleting data');
//   } finally {
//     if (connection) {
//       try {
//         await connection.close();
//       } catch (err) {
//         console.error('Error closing connection:', err);
//       }
//     }
//   }
// }); 
app.get('/getRecords', async (_req, res) => {
  let connection;
  try {
    connection = await connectDB();
    const sqlQuery = 'SELECT * FROM custom.leave';
    const result = await connection.execute(sqlQuery);
    const employees = result.rows.map((row) => { 
      return {
        id: row[0], 
        leave_type: row[1],
        employee_id: row[2],
        start_date: row[3],
        end_date: row[4], 
        lev_reason: row[5],
        lev_approve: row[6],
        lev_status: row[7],
      };
    });
    console.log(employees); 
    res.json({ employees: employees });
  } catch (err) {
    console.error("Error:", err.message);
    res.status(500).send('Internal Server Error');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error("Error closing the database connection:", err.message);
      }
    }
  }
});


 
 

// app.get('/sickl', async (_req, res) => {
//   let connection;
//   try {
//     connection = await connectDB();
//     const query = "SELECT COUNT(*) AS sickLeaveCount FROM custom.leave WHERE leave_type='Sick leave' AND lev_status = 'Approved'";
//     const result = await connection.execute(query); 
//     let sickLeaveCount;
//     if (result.rows && result.rows.length > 0) { 
//       sickLeaveCount = result.rows[0][0];
//     } 
//     res.json({ sick: [{ sickLeaveCount: sickLeaveCount }] });
//     console.log(sickLeaveCount);
//     console.log("Sick leave count:", sickLeaveCount);
//   } catch (err) {
//     console.error("Error counting sick leaves:", err);
//     res.status(500).send({ message: "An error occurred while counting sick leaves." });
//   } finally {
//     if (connection) {
//       try {
//         await connection.close();
//       } catch (err) {
//         console.error("Error closing the database connection:", err.message);
//       }
//     }
//   }
// });
// app.get('/sickl', async (_req, res) => {
//   let connection;
//   try {
//     connection = await connectDB();

//     const query = `
//       WITH date_ranges AS (
//         SELECT l.start_date, l.end_date
//         FROM custom.leave l
//       ),
//       all_dates AS (
//         SELECT start_date + LEVEL - 1 AS current_date
//         FROM date_ranges
//         CONNECT BY LEVEL <= (end_date - start_date + 1)
//       )
//       SELECT COUNT(*)
//       FROM custom.leave
//       WHERE TO_CHAR(current_date, 'DY', 'NLS_DATE_LANGUAGE=ENGLISH') NOT IN ('SAT', 'SUN')
//     `;

//     const result = await connection.execute(query);
//     let sickLeaveCount;
//     if (result.rows && result.rows.length > 0) {
//       sickLeaveCount = result.rows[0][0];
//     }

//     res.json({ sick: [{ sickLeaveCount: sickLeaveCount }] });
//     console.log("Sick leave count:", sickLeaveCount);
//   } catch (err) {
//     console.error("Error counting sick leaves:", err);
//     res.status(500).send({ message: "An error occurred while counting sick leaves." });
//   } finally {
//     if (connection) {
//       try {
//         await connection.close();
//       } catch (err) {
//         console.error("Error closing the database connection:", err.message);
//       }
//     }
//   }
// });
app.get('/sickl', async (_req, res) => {
  let connection; 
  try {
    connection = await connectDB(); 
    const query = `
      WITH date_ranges AS (
        SELECT start_date, end_date
        FROM custom.leave
      ),
      all_dates AS (
        SELECT start_date + LEVEL - 1 AS current_date
        FROM date_ranges
        CONNECT BY LEVEL <= (end_date - start_date + 1)
      )
      SELECT COUNT(*)
      FROM custom.leave
      WHERE TO_CHAR(current_date, 'DY', 'NLS_DATE_LANGUAGE=ENGLISH') != 'SUN' `; 
     const result = await connection.execute(query);
    let sickLeaveCount = 0; 
    if (result.rows && result.rows.length > 0) {
      sickLeaveCount = result.rows[0][0];
    } 
    res.json({ sick: [{ sickLeaveCount: sickLeaveCount }] });
    console.log("Sick leave count:", sickLeaveCount);
  } catch (err) {
    console.error("Error counting sick leaves:", err);
    res.status(500).send({ message: "An error occurred while counting sick leaves." });
  } finally {
    if (connection) { 
      try {
        await connection.close();
      } catch (err) {
        console.error("Error closing the database connection:", err.message);
      }
    }
  }
});
 
// app.get('/sickl', async (_req, res) => {
//   let connection;

//   try {
//     connection = await connectDB(); 
//     const query = `
//       WITH date_ranges AS (
//         SELECT start_date, end_date
//         FROM custom.leave
//       ),
//       all_dates AS (
//         SELECT start_date + LEVEL - 1 AS current_date
//         FROM date_ranges
//         CONNECT BY LEVEL <= (end_date - start_date + 1)
//       )
//       SELECT COUNT(*)
//       FROM custom.leave
//       WHERE TO_CHAR(current_date, 'DY', 'NLS_DATE_LANGUAGE=ENGLISH') NOT IN ('SUN')
//     `;

//     const result = await connection.execute(query);
//     let sickLeaveCount;
//     if (result.rows && result.rows.length > 0) {
//       sickLeaveCount = result.rows[0][0];
//     }

//     res.json({ sick: [{ sickLeaveCount: sickLeaveCount }] });
//     console.log("Sick leave count:", sickLeaveCount);
//   } catch (err) {
//     console.error("Error counting sick leaves:", err);
//     res.status(500).send({ message: "An error occurred while counting sick leaves." });
//   } finally {
//     if (connection) {
//       try {
//         await connection.close();
//       } catch (err) {
//         console.error("Error closing the database connection:", err.message);
//       }
//     }
//   }
// });


// app.get('/absent', async (_req, res) => {
//   let connection;
//   try {
//     connection = await connectDB();
//     const query = "SELECT COUNT(*) AS absentCount FROM custom.leave WHERE start_date = TO_CHAR(SYSDATE, 'YYYY-MM-DD')";
//     const result = await connection.execute(query);
//     const absend = result.rows[0][0]; 
//     res.json({  absendu: [{ absend }] }); // Send the desired output format
//     console.log("Onsite employee Count :", absend);
//   } catch (err) {
//     console.error("Error counting male employees:", err);
//     res.status(500).send({ message: "An error occurred while counting male employees." });
//   } finally {
//     if (connection) {
//       try {
//         await connection.close();
//       } catch (err) {
//         console.error("Error closing the database connection:", err.message);
//       }
//     }
//   }
// });


// app.get('/absent', async (req, res) => {
//   let connection;
//   try {
//     connection = await connectDB();
//     const currentDate = new Date().toISOString().slice(0, 10); // Format current date as YYYY-MM-DD
//     const query = `
//       SELECT COUNT(employee_id) AS absentCount
//       FROM custom.leave 
//       WHERE TO_DATE(:currentDate, 'YYYY-MM-DD') BETWEEN start_date AND end_date AND lev_approve = 'Approved'`;
//     const result = await connection.execute(query, { currentDate }); 
//     const absentCount = result.rows[0][0];
//     res.json({ leave: [{ absentCount }] });
//     console.log("Absent count:", absentCount);
//   } catch (err) {
//     console.error("Error fetching absent employees:", err);
//     res.status(500).send({ message: "An error occurred while fetching absent employees." });
//   } finally {
//     if (connection) {
//       try {
//         await connection.close();
//       } catch (err) {
//         console.error("Error closing connection:", err);
//       }
//     }
//   }
//  });

app.get('/absent', async (req, res) => {
  let connection;
  try {
    connection = await connectDB();
    const currentDate = new Date().toISOString().slice(0, 10);  

    const query = `
      SELECT COUNT(employee_id) AS absentCount
FROM custom.leave
WHERE :currentDate BETWEEN TO_CHAR(start_date, 'YYYY-MM-DD') AND TO_CHAR(end_date, 'YYYY-MM-DD')
AND lev_status = 'approved'`; 
    const result = await connection.execute(query, { currentDate }); 
    const absentCount = result.rows[0][0]; 
    res.json({ leave: [{ absentCount }] }); 
    console.log("Absent count:", absentCount,currentDate); 
  } catch (err) {
    console.error("Error fetching absent employees:", err);
    res.status(500).send({ message: "An error occurred while fetching absent employees." });
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error("Error closing connection:", err);
      }
    }
  }
});

 


app.get('/casul', async (_req, res) => {
  let connection;
  try {
    connection = await connectDB();
    const query = "SELECT COUNT(*) AS onsiteCount FROM custom.leave WHERE leave_type='Casual leave'";
    const result = await connection.execute(query);
    const casual = result.rows[0][0];   
    res.json({  casuall: [{ casual }] }); 
    console.log("Onsite employee Count :", casual);
  } catch (err) {
    console.error("Error counting male employees:", err);
    res.status(500).send({ message: "An error occurred while counting male employees." });
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error("Error closing the database connection:", err.message);
      }
    }
  }
});
 

// app.get('/leaveDuration', async (req, res) => {
//   let connection; 
//   try {
//     connection = await connectDB(); 
//     const {  start_date, end_date } = req.query; 
//     const startDate = new Date(start_date);
//     const endDate = new Date(end_date);  
//     let totalDays = Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24)) + 1; 
//     let sundays = 0;
//     for (let date = new Date(startDate); date <= endDate; date.setDate(date.getDate() + 1)) {
//       if (date.getDay() === 0) {
//         sundays++;
//       }
//     } 
//     const holidaysQuery = "SELECT * FROM custom.leave  WHERE BETWEEN :start_date AND :end_date";
//     const holidaysResult = await connection.execute(holidaysQuery, { start_date: start_date, end_date: end_date });
//     const holidays = holidaysResult.rows.map(row => new Date(row[0]).toISOString().slice(0, 10));
//     let holidaysCount = holidays.length; 
//     const leaveDuration = totalDays - sundays - holidaysCount; 
//     res.json({ leaveDuration });
//   } catch (err) {
//     console.error("Error calculating leave duration:", err);
//     res.status(500).send({ message: "An error occurred while calculating leave duration." });
//   } finally {
//     if (connection) {
//       try {
//         await connection.close();
//       } catch (err) {
//         console.error("Error closing connection:", err);
//       }
//     }
//   }
// });

app.get('/paided', async (_req, res) => {
  let connection;
  try {
    connection = await connectDB();
    const query = "SELECT COUNT(*) AS onsiteCount FROM custom.leave WHERE leave_type='Paid leave'";
    const result = await connection.execute(query);
    const paid = result.rows[0][0];   
    res.json({  paidedl: [{ paid }] }); 
    console.log("Onsite employee Count :", paid);
  } catch (err) {
    console.error("Error counting male employees:", err);
    res.status(500).send({ message: "An error occurred while counting male employees." });
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error("Error closing the database connection:", err.message);
      }
    }
  }
});

 
app.post("/comment", async(req, res) => {
  let connection;
  try{
    connection = await connectDB()
  const {  employee_name, father_name, employee_id, personal_email, work_email, mobile, gender, dob, marital_status, location, permanent, employee_Ref, remark, department, designation, reporting, pan_no, aadhar, bankac, uanno, pfno,bankName, startjoin,blood_G} = req.body; 
  const sql = "INSERT INTO custom.employee (employee_name, father_name, employee_id, personal_email, work_email, mobile, gender, dob, marital_status, location, permanent, employee_Ref, remark, department, designation, reporting, pan_no, aadhar, bankac, uanno, pfno ,startjoin,bankName, blood_G) VALUES (:employee_name, :father_name, :employee_id, :personal_email, :work_email, :mobile, :gender, :dob, :marital_status, :location, :permanent, :employee_Ref, :remark, :department, :designation, :reporting, :pan_no, :aadhar, :bankac, :uanno, :pfno, :bankName, :startjoin ,:blood_G )";
  const values = [employee_name, father_name, employee_id, personal_email, work_email, mobile, gender, dob, marital_status, location, permanent, employee_Ref, remark, department, designation, reporting, pan_no, aadhar, bankac, uanno, pfno, bankName,startjoin,blood_G];
  await connection.execute(sql, values, { autoCommit: true });
    res.send("User leave applied successfully");
  } catch (err) {
    console.error("Error inserting user:", err);
    res.status(500).send({ message: "An error occurred while applying for leave."});
  }
}); 
 
app.delete('/empdelete/:id', async (req, res) => {
  let connection;
  try {
    const id = req.params.id;  
    connection = await connectDB(); 
    const selectQuery = 'SELECT * FROM custom.employee WHERE id = :id';
    const selectedData = await connection.execute(selectQuery, { id }, { outFormat: connection.OBJECT }); 
    const archiveQuery = 'INSERT INTO custom.employee_archive SELECT * FROM custom.employee WHERE id = :id';
    await connection.execute(archiveQuery, { id }, { autoCommit: false }); 
    const delQuery = 'DELETE FROM custom.employee WHERE id = :id'; 
    await connection.execute(delQuery, { id }, { autoCommit: false }); 
    await connection.commit(); 
    res.send("Data archived and deleted successfully");
  } catch (err) {
    console.error('Error executing query:', err);
    res.status(500).send('Error processing request'); 
    if (connection) {
      await connection.rollback();
    }
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error('Error closing connection:', err);
      }
    }
  }
});
// app.put('/emptableupdate/:id', async (req, res) => {
//   let connection;
//   try {
//     connection = await connectDB();
//     const  id = req.params.id;
//     const { employee_name, designation, employee_id, work_email, mobile, permanent, reporting } = req.body;
//     const update = "UPDATE custom.tasktime SET employee_name = :employee_name, designation =:designation, employee_id = :employee_id, work_email = :work_email, mobile = :mobile, permanent = :permanent, reporting = :reporting WHERE id = :id";
//     const params = { employee_name, designation, employee_id, work_email, mobile, permanent, reporting, id:id }; 
//     const result = await connection.execute(update, params, { autoCommit: true });
//     res.send("Data updated successfully");
//     console.log(result);
//   } catch (err) {
//     console.error('Error executing query:', err);
//     res.status(500).send('Error updating data');
//   } finally {
//     if (connection) {
//       try {
//         await connection.close();
//       } catch (err) {
//         console.error('Error closing connection:', err);
//       }
//     }
//   }
// });


// app.put('/emptabupdate/:id', async (req, res) => {
//   let connection;
//   try {
//     const id = req.params.id;
//     const {employee_name, designation, employee_id, work_email, mobile, permanent, reporting} = req.body; 
//     connection = await connectDB();
//     const update = "UPDATE custom.employee SET employee_name = :uemployee_name, designation =:udesignation, employee_id = :uemployee_id, work_email = :uwork_email, mobile = :umobile, permanent = :upermanent, reporting = :ureporting WHERE id = :id"; 
//     const code = { employee_name, designation, employee_id, work_email, mobile, permanent, reporting, id: id };  
//     const result = await connection.execute(update, code, { autoCommit: true });
//     res.send("Data updated successfully");
//     console.log(result)
//   } catch (err) {
//     console.error('Error executing query:', err);
//     res.status(500).send('Error updating data');
//   } finally {
//     if (connection) {
//       try {
//         await connection.close();
//       } catch (err) {
//         console.error('Error closing connection:', err);
//       }
//     }
//   }
// });  


app.put('/emptabupdate/:id', async (req, res) => {
  let connection;
  try {
    const id = req.params.id;
    const {
      employee_name: uemployee_name,
      designation: udesignation,
      employee_id: uemployee_id,
      work_email: uwork_email,
      mobile: umobile,
      permanent: upermanent,
      reporting: ureporting
    } = req.body; 

    connection = await connectDB();
    
    const update = `
      UPDATE custom.employee 
      SET 
        employee_name = :uemployee_name, 
        designation = :udesignation, 
        employee_id = :uemployee_id, 
        work_email = :uwork_email, 
        mobile = :umobile, 
        permanent = :upermanent, 
        reporting = :ureporting 
      WHERE id = :id
    `;

    const code = { 
      uemployee_name, 
      udesignation, 
      uemployee_id, 
      uwork_email, 
      umobile, 
      upermanent, 
      ureporting, 
      id 
    };  

    const result = await connection.execute(update, code, { autoCommit: true });

    res.send("Data updated successfully");
    console.log(result);
  } catch (err) {
    console.error('Error executing query:', err);
    res.status(500).send('Error updating data');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error('Error closing connection:', err);
      }
    }
  }
});


app.get('/setting', async (_req, res) => {
  let connection;
  try {
    connection = await connectDB();
    const sqlQuery = 'SELECT * FROM custom.employee';
    const result = await connection.execute(sqlQuery);
    const details = result.rows.map((row) => { 
      return {
        id: row[0], 
        employee_name: row[1],
        designation: row[15],
        employee_id: row[3],
        work_email: row[5],
        mobile: row[6],
        reporting:row[16],
        startjoin:row[23],
        permanent:row[11]
      };
    });
    console.log(details); 
    res.json({ details: details });
  } catch (err) {
    console.error("Error:", err.message);
    res.status(500).send('Internal Server Error');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error("Error closing the database connection:", err.message);
      }
    }
  }
});


// const storage = multer.memoryStorage(); // Store files in memory (you can adjust this)

// const upload = multer({ storage });
// app.post("/upload", upload.array("files", 5), async (req, res) => {
//   let connection;
//   try {
//     connection = await connectDB();
//     const upload = req.files;
//     const file = 'INSERT INTO custom.uploadfile (upload) VALUES (:upload)';
//     const result = { upload };
//     const response = await connection.execute(file, result, { autoCommit: true });
//     res.status(200).send("Files uploaded successfully!");
//     res.send(response);
//   } catch (error) {
//     console.log(error, "error");
//   }
// });

// app.post('/count-employees', async (_req, res) => {
//   let connection;
//   try {
//     connection = await connectDB();
//     const query = "SELECT COUNT(*) FROM custom.employee WHERE gender='Male'";
//     const result = await connection.execute(query);
//     const maleCount = result.rows[0].MALECOUNT;
//     res.send({ maleCount });
//     console.log(maleCount)
//   } catch (err) {
//     console.error("Error counting male employees:", err);
//     res.status(500).send({ message: "An error occurred while counting male employees." });
//   }
// });


app.get('/count', async (_req, res) => {
  let connection;
  try {
    connection = await connectDB();
    const query = "SELECT employee_name, father_name, employee_id, personal_email, work_email, mobile, gender, dob, marital_status, location, permanent, employee_Ref, remark, department, designation, reporting, pan_no, aadhar, bankac, uanno, pfno, bankName, startjoin, blood_G FROM custom.employee";  
    const result = await connection.execute(query);
    
    
    const comments = result.rows.map((row) => {
      return {
        employeeName: row[0],
        fatherName: row[1],
        employeeId: row[2],
        personalEmail: row[3],
        workEmail: row[4],
        mobile: row[5],
        gender: row[6],
        dob: row[7],
        maritalStatus: row[8],
        location: row[9],
        permanent: row[10],
        employeeRef: row[11],
        remark: row[12],
        department: row[13],
        designation: row[14],
        reporting: row[15],
        panNo: row[16],
        aadhar: row[17],
        bankAc: row[18],
        uanNo: row[19],
        pfNo: row[20],
        startjoin:row[21],
        bankName:row[22],
        blood_G:row[23],
      };
    });
    
    res.json({ comments: comments, count: comments.length });
    console.log("total: ",comments.length);  
  } catch (err) {
    console.error("Error fetching records:", err);
    res.status(500).send({ message: "An error occurred while fetching records." });
  } finally {
    if (connection) {
      try {
        await connection.close();  
      } catch (err) {
        console.error("Error closing the database connection:", err.message);
      }
    }
  }
});

app.post("/file", express.static(__dirname + "/public"));
app.get('/countemployees', async (_req, res) => {
  let connection;
  try {
    connection = await connectDB();
    const query = "SELECT COUNT(*) AS maleCount FROM custom.employee WHERE gender='Male'";
    const result = await connection.execute(query);
    const maleCount = result.rows[0][0];  

    res.json({  gender: [{ maleCount }] });  
    console.log("Male count:", maleCount);
  } catch (err) {
    console.error("Error counting male employees:", err);
    res.status(500).send({ message: "An error occurred while counting male employees." });
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error("Error closing the database connection:", err.message);
      }
    }
  }
});
app.get('/femaleCount', async (_req, res) => {
  let connection;
  try {
    connection = await connectDB();
    const query = "SELECT COUNT(*) AS femaleCount FROM custom.employee WHERE gender='Female'";
    const result = await connection.execute(query);
    const femaleCount = result.rows[0][0];  

    res.json({ fgender: [{ femaleCount }] });  
    console.log("Female count:", femaleCount);
  } catch (err) {
    console.error("Error counting male employees:", err);
    res.status(500).send({ message: "An error occurred while counting male employees." });
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error("Error closing the database connection:", err.message);
      }
    }
  }
});

app.put('/taskupdate/:id', async (req, res) => {
  let connection;
  try {
    connection = await connectDB();
    const id = req.params.id;
    const { utask_name, utask_description, uemp_task, ustart_task, uend_task, uemp_position, utaskpriority } = req.body;

    const updateQuery = `
      UPDATE custom.tasktime 
      SET taskname = :utask_name, 
          taskdescription = :utask_description, 
          emptask = :uemp_task, 
          starttask = :ustart_task, 
          endtask = :uend_task, 
          empposition = :uemp_position, 
          taskpriority = :utaskpriority 
         WHERE id = :id
    `;

    const params = { utask_name, utask_description, uemp_task, ustart_task, uend_task, uemp_position, utaskpriority, id };
    const result = await connection.execute(updateQuery, params, { autoCommit: true });

    res.status(200).send("Data updated successfully");
    console.log(result);
  } catch (err) {
    console.error('Error executing query:', err);
    res.status(500).send('Error updating data');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error('Error closing connection:', err);
      }
    }
  }
});

app.post("/tasktime2", async (req, res) => {
  let connection;
  try {
    connection = await connectDB();
    const { taskname,taskdescription,emptask,starttask,endtask,empposition,taskpriority} = req.body;
    const sql = "INSERT INTO custom.tasktime (taskname,taskdescription,emptask,starttask,endtask,empposition,taskpriority) VALUES (:taskname, :taskdescription, :emptask, :starttask, :endtask, :empposition, :taskpriority)";
    const values = { taskname,taskdescription,emptask,starttask,endtask,empposition,taskpriority };
    await connection.execute(sql, values, { autoCommit: true });
    res.send("Task created successfully");
  } catch (err) {
    console.error("Error inserting task:", err);
    res.status(500).send({ message: "An error occurred while creating the task." });
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error("Error closing connection:", err);
      }
    }
  }
});

// app.delete('/taskdelete/:id', async (req, res) => {
//   let connection;
//   try {
//     const id = req.params.id;
//     connection = await connectDB(); 
//     const delQuery = 'DELETE FROM custom.tasktime WHERE id = :id';
//     await connection.execute(delQuery, { id }, { autoCommit: true }); 
//     const archiveQuery = 'INSERT INTO custom.tasktime_archive (id) VALUES (:id)';
//     await connection.execute(archiveQuery, { id }, { autoCommit: true });

//     res.send("Data deleted successfully");
//   } catch (err) {
//     console.error('Error executing query:', err);
//     res.status(500).send('Error deleting data');
//   } finally {
//     if (connection) {
//       try {
//         await connection.close();
//       } catch (err) {
//         console.error('Error closing connection:', err);
//       }
//     }
//   }
// });



app.delete('/taskdelete/:id', async (req, res) => {
  let connection;
  try {
    const id = req.params.id;
    connection = await connectDB(); 

    // Step 1: Delete from main table
    const delQuery = 'DELETE FROM custom.tasktime WHERE id = :id';
    await connection.execute(delQuery, { id }, { autoCommit: true });

    // Step 2: Archive into archive table
    const archiveQuery = 'INSERT INTO custom.task_archive (id, taskname, taskdescription, emptask, starttask, endtask, empposition, taskpriority) ' +
                         'SELECT id, taskname, taskdescription, emptask, starttask, endtask, empposition, taskpriority ' +
                         'FROM custom.tasktime WHERE id = :id';
    await connection.execute(archiveQuery, { id }, { autoCommit: true });

    res.send("Data deleted and archived successfully");
  } catch (err) {
    console.error('Error executing query:', err);
    res.status(500).send('Error deleting data');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error('Error closing connection:', err);
      }
    }
  }
});


app.get('/taskdisplay', async (_req, res) => {
  let connection;
  try {
    connection = await connectDB();
    const sqlQuery = 'SELECT * FROM custom.tasktime';
    const result = await connection.execute(sqlQuery);
    const displaytask = result.rows.map((row) => { 
      return {
        id: row[0], 
        taskname: row[1],
        taskdescription: row[2],
        emptask: row[3],
        starttask: row[4],
        endtask: row[5],
        empposition:row[6],
        taskpriority:row[7] 
      };
    });
    console.log(displaytask); 
    res.json({ displaytask: displaytask });
  } catch (err) {
    console.error("Error:", err.message);
    res.status(500).send('Internal Server Error');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error("Error closing the database connection:", err.message);
      }
    }
  }
});
// app.post("/tasktime2", async (req, res) => {
//   let connection;
//   try {
//     connection = await connectDB();
//     const { task_name, task_description, emp_task, start_task, end_task, emp_position } = req.body;
//     const sql = "INSERT INTO custom.tasktime (task_name, task_description, emp_task, start_task, end_task, emp_position) VALUES (:task_name, :task_description, :emp_task, :start_task, :end_task, :emp_position)";
//     const values = { task_name, task_description, emp_task, start_task, end_task, emp_position };
//     await connection.execute(sql, values, { autoCommit: true });
//     res.send("Task created successfully");    
//   } catch (err) {
//     console.error("Error inserting task:", err);   
//     res.status(500).send({ message: "An error occurred while creating the task." });
//   } finally {
//     if (connection) {
//       try {
//         await connection.close();
//       } catch (err) {
//         console.error("Error closing connection:", err);
//       }
//     }
//   }
// });
const PORT = process.env.PORT || 3015;
app.listen(PORT, async () => {
  try {
    await connectDB();
    console.log("Running backend server on port", PORT);
  } catch (err) {
    console.error("Error starting backend server:", err);
  }
});














































// working JWT:

// require('dotenv').config();
// const express = require("express");
// const oracledb = require("oracledb");
// const cors = require("cors");
// const jwt = require("jsonwebtoken");
 
// const app = express();
// app.use(express.json());
// app.use(cors());

// const corsOptions = {
//   origin: ['http://localhost:3000', 'http://localhost:3015'],
//   credentials: true,
// };
// app.use(cors(corsOptions)); 
// async function connectDB() {
//   let connection;
//   try {
//     connection = await oracledb.getConnection({
//       user: process.env.DB_USER || "custom",
//       password: process.env.DB_PASSWORD || "custom",
//       connectString: process.env.DB_CONNECT_STRING || "dbfin:1521/FINMULTI"
//     });
//     console.log("Successfully connected to Oracle Database");
//     return connection;
//   } catch (err) {
//     console.error("Error connecting to Oracle Database:", err);
//     throw err;
//   }
// } 
// function generateAccessToken(user) {
//   return jwt.sign(user, process.env.ACCESS_TOKEN_SECRET, { expiresIn: '1800s' });
// } 
 

// app.post('/sign', async (req, res) => {
//   let connection;
//   try {
//     connection = await connectDB();
//     const { emp_name, mobile, department, emp_email, password, emp_address, emp_designation } = req.body;
     
//     const checkUserQuery = "SELECT COUNT(*) AS count FROM custom.login WHERE emp_email = :emp_email";
//     const checkUserParams = { emp_email };
//     const userCheckResult = await connection.execute(checkUserQuery, checkUserParams);

//     if (userCheckResult.rows[0][0] > 0) {
//       res.status(409).send({ message: "User already exists with this email." });
//       return;
//     } 
//     const insert = "INSERT INTO custom.login (emp_name, mobile, department, emp_email, password, emp_address, emp_designation) VALUES (:emp_name, :mobile, :department, :emp_email, :password, :emp_address, :emp_designation)";
//     const binds = { emp_name, mobile, department, emp_email, password, emp_address, emp_designation };
//     await connection.execute(insert, binds, { autoCommit: true }); 
//     const user = { name: emp_name };
//     const accessToken = generateAccessToken(user);
//     res.json({ accessToken: accessToken });
//   } catch (err) {
//     console.error("Error inserting user:", err);
//     res.status(500).send({ message: "An error occurred while registering the user." });
//   } finally {
//     if (connection) {
//       try {
//         await connection.close();
//       } catch (err) {
//         console.error("Error closing connection:", err);
//       }
//     }
//   }
// });  
// app.get("/login", async (req, res) => {
//   let connection;
//   try {
//     connection = await connectDB();
//     const { emp_email, password } = req.body;
//     const select = "SELECT emp_name FROM custom.login WHERE emp_email = :emp_email AND password = :password";
//     const selectParams = { emp_email, password };
//     const result = await connection.execute(select, selectParams); 
//     if (result.rows.length > 0) {
//       const user = { name: result.rows[0][0] };  
//       const accessToken = generateAccessToken(user);
//       res.json({ accessToken: accessToken });
//     } else {
//       res.status(401).send({ message: "Invalid credentials." });
//     }
//   } catch (err) {
//     console.error('Error executing query:', err);
//     res.status(500).send({ message: "An error occurred while logging in." }); 
//   } finally {
//     if (connection) {
//       try {
//         await connection.close();
//       } catch (err) {
//         console.error("Error closing connection:", err);
//       }
//     }
//   }
// }); 
// app.get('/posts', authenticateToken, (req, res) => {
//   res.json({ message: "Here are the posts", user: req.user });
// }); 
// function authenticateToken(req, res, next) {
//   const authHeader = req.headers['authorization'];
//   const token = authHeader && authHeader.split(' ')[1]; 
//   if (token == null) {
//     console.error('No token provided');
//     return res.sendStatus(401); 
//   } 
//   jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {
//     if (err) {
//       console.error('Token verification failed:', err);
//       return res.sendStatus(403); 
//     }
//     req.user = user;
//     next();
//   });
// } 
// const PORT = process.env.PORT || 3015;
// app.listen(PORT, async () => {
//   try {
//     await connectDB();
//     console.log("Running backend server on port", PORT);
//   } catch (err) {
//     console.error("Error starting backend server:", err);
//   }
// });


// require('dotenv').config();
// const express = require("express");
// const oracledb = require("oracledb");
// const cors = require("cors");
// const jwt = require("jsonwebtoken");

// const app = express();
// app.use(express.json());
// app.use(cors());

// const corsOptions = {
//   origin: ['http://localhost:3000', 'http://localhost:3015'],
//   credentials: true,
// };
// app.use(cors(corsOptions));

// async function connectDB() {
//   try {
//     const connection = await oracledb.getConnection({
//       user: process.env.DB_USER,
//       password: process.env.DB_PASSWORD,
//       connectString: process.env.DB_CONNECT_STRING
//     });
//     console.log("Successfully connected to Oracle Database");
//     return connection;
//   } catch (err) {
//     console.error("Error connecting to Oracle Database:", err);
//     throw err;
//   }
// }

// function generateAccessToken(user) {
//   return jwt.sign(user,process.eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.hqd6lc6FVmAYT_vQyDPgVzoJbxf0kNxIybtQ7YW_NVE, { expiresIn: '1800s' });
// }

// app.get('/sign', async (req, res) => {
//   let connection;
//   try {
//     connection = await connectDB();
//     const { emp_name, mobile, department, emp_email, password, emp_address, emp_designation } = req.body;
     
//     const checkUserQuery = "SELECT COUNT(*) AS count FROM custom.login WHERE emp_email = :emp_email";
//     const checkUserParams = { emp_email };
//     const result = await connection.execute(checkUserQuery, checkUserParams);
    
//     if (result.rows[0][0] > 0) {
//       res.status(409).send({ message: "User already exists with this email." });
//       return;
//     }
//     const insert = `INSERT INTO custom.login 
//       (emp_name, mobile, department, emp_email, password, emp_address, emp_designation) 
//       VALUES (:emp_name, :mobile, :department, :emp_email, :password, :emp_address, :emp_designation)`;
//     const binds = { emp_name, mobile, department, emp_email, password, emp_address, emp_designation };
//     await connection.execute(insert, binds, { autoCommit: true });

//     const user = { name: emp_name };
//     const accessToken = generateAccessToken(user);
//     res.json({ accessToken: accessToken });
//   } catch (err) {
//     console.error("Error inserting user:", err);
//     res.status(500).send({ message: "An error occurred while registering the user." });
//   } finally {
//     if (connection) {
//       try {
//         await connection.close();
//       } catch (err) {
//         console.error("Error closing connection:", err);
//       }
//     }
//   }
// });

// app.post('/server', async (req, res) => {
//   let connection;
//   try {
//     connection = await connectDB();
//     const { emp_email, password } = req.body;
//     const select = "SELECT * FROM custom.login WHERE emp_email = :emp_email AND password = :password";
//     const selectParams = { emp_email, password };
//     const result = await connection.execute(select, selectParams);
    
//     if (result.rows.length > 0) {
//       const user = { name: result.rows[0][0] };  
//       const accessToken = generateAccessToken(user);
//       res.json({ accessToken: accessToken });
//     } else {
//       res.status(401).send({ message: "Invalid credentials." });
//     }
//   } catch (err) {
//     console.error('Error executing query:', err);
//     res.status(500).send({ message: "An error occurred while logging in." });
//   } finally {
//     if (connection) {
//       try {
//         await connection.close();
//       } catch (err) {
//         console.error("Error closing connection:", err);
//       }
//     }
//   }
// });

// app.get('/posts', authenticateToken, (req, res) => {
//   res.json({ message: "Here are the posts", user: req.user });
// });

// function authenticateToken(req, res, next) {
//   const authHeader = req.headers['authorization'];
//   const token = authHeader && authHeader.split(' ')[1];
  
//   if (token == null) return res.sendStatus(401);
  
//   jwt.verify(token, process.eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.hqd6lc6FVmAYT_vQyDPgVzoJbxf0kNxIybtQ7YW_NVE, (err, user) => {
//     if (err) return res.sendStatus(403);
    
//     req.user = user;
//     next();
//   });
// }

// const PORT = process.env.PORT || 3015;
// app.listen(PORT, async () => {
//   try {
//     await connectDB();
//     console.log("Running backend server on port", PORT);
//   } catch (err) {
//     console.error("Error starting backend server:", err);
//   }
// });
