import React, { useState, useEffect } from 'react';
import './login.css';
import Signlogo from './assets/company.png';
import { Link, useNavigate } from 'react-router-dom';
import Axios from 'axios';

function Login({onLogin}) {
  const [emp_email, setBusinessEmail] = useState('');
  const [password, setPassword] = useState('');
  const [Rolead, setRoleAd] = useState('');
  const [message, setMessage] = useState('');
  const [token, setToken] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    window.history.pushState(null, '', window.location.href);
    window.onpopstate = function (_event) {
      window.history.pushState(null, '', window.location.href);
    };

    window.onbeforeunload = function () {
      return "Are you sure you want to leave?";
    };
  }, []);

  const login = async (e) => {
    e.preventDefault();

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(emp_email)) {
      window.alert("Please enter a valid Email Address.");
      return;
    }
    const minPasswordLength = 8;
    const passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).{8,}$/;
    if (!passwordRegex.test(password) || password.length < minPasswordLength) {
      window.alert("Please enter a valid password.");
      return;
    }
    try {
      const response = await Axios.post("http://192.168.1.151:3015/server", {
        emp_email: emp_email,
        password: password,
        Rolead: Rolead
      });

      if (response.data.message) {
        setToken(response.data.token);
        window.alert("Account logged in successfully"); 
        if (Rolead === 'admin') {
          onLogin('admin');
          navigate('/adminDash');
        } else if (Rolead === 'employee') {
          onLogin('employee');
          navigate('/dashboard');
        }
        sessionStorage.setItem('userRole', Rolead);
      }
    } catch (error) {
      setMessage(error.response?.data?.message || 'An error occurred.');
      alert("Unauthorized username or password");
      console.error("Error during login:", error);
    }
  };
  useEffect(() => {
    document.body.style.backgroundColor = '#e6f1fc';
    document.body.style.width = '100%';
    document.body.style.height = '100%';
    document.body.style.overflow = 'none';
    document.body.style.fontFamily = 'Inter, sans-serif';
    return () => {
      document.body.style.backgroundColor = '#e6f1fc';
    };
  }, []);
  return (
<div style={{ body: "#f9f9f9" }}>
         <div className="lion" style={{ backgroundColor: "#e6f1fc" }}>
        <header className='imageadd'>
          <img src={Signlogo} height="100px" width="400px" alt="" />
        </header>
        <div class="cta-form"></div>
        <div className='tec'>
          <form className='frame' onSubmit={login}>
            <center><h2>LOGIN IN NOW</h2></center>
            <p><span className='ciju'> Use the form below to create your account.</span></p>
            <br></br>
            <input type="text"  
            placeholder="Business Email" autocomplete="off" required onChange={(e)=>{setBusinessEmail(e.target.value)}}  classname="input" id="businessemail" />
        <br></br> 
        <input type="text"
             placeholder="Password" required autocomplete="off" onChange={(e)=>{setPassword(e.target.value)}} classname="input" id="password" />
         <br></br> 
          <select  
             placeholder="Password"  style={{marginBottom:"30px",height:"50px",width:"400px",borderColor:"#e6f1fc",backgroundColor:"#b5d3d7",borderRadius:"10px"}} autocomplete="off" value={Rolead}onChange={(e)=>{setRoleAd(e.target.value)}} classname="input"  id="password" >
                  <option value="">select</option>  
                  <option value="admin">admin</option>     
                  <option value="employee">employee</option>   1  
             </select>
             {/* <input type='checkbox' className='input' style={{height:"20px", width:"20px",marginLeft:"10px"}}  /><span>you are admin only check-in </span> */}
            <Link className='b1' to="/sign">Signup</Link>
            <button type="submit" className='b2'>Login</button>
          </form>
        </div>
        <br></br>
      </div>
    </div>
  );
} 
export default Login;
 

// import React, { useState, useEffect } from 'react';
// import './login.css';
// import Signlogo from './assets/company.png';
// import { Link, useNavigate } from 'react-router-dom';
// import Axios from 'axios';

// function Login() {
//   const [emp_email, setBusinessEmail] = useState('');
//   const [password, setPassword] = useState('');
//   const [Rolead, setRoleAd] = useState('');
//   const [message, setMessage] = useState('');
//   const [token, setToken] = useState('');
//   const navigate = useNavigate();

//   useEffect(() => {
//     window.history.pushState(null, '', window.location.href);
//     window.onpopstate = function (_event) {
//       window.history.pushState(null, '', window.location.href);
//     };

//     window.onbeforeunload = function () {
//       return "Are you sure you want to leave?";
//     };
//   }, []);

//   const login = async (e) => {
//     e.preventDefault();

//     const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
//     if (!emailRegex.test(emp_email)) {
//       window.alert("Please enter a valid Email Address.");
//       return;
//     }
//     const minPasswordLength = 8;
//     const passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).{8,}$/;
//     if (!passwordRegex.test(password) || password.length < minPasswordLength) {
//       window.alert("Please enter a valid password.");
//       return;
//     }
//     try {
//       const response = await Axios.post("http://localhost:3015/server", {
//         emp_email: emp_email,
//         password: password,
//         Rolead: Rolead
//       });

//       if (response.data.message) {
//         setToken(response.data.token);
//         window.alert("Account logged in successfully");

//         sessionStorage.setItem('userRole', Rolead);
//         sessionStorage.setItem('token', response.data.token);
//         sessionStorage.setItem('isLoggedIn', true);

//         if (Rolead === 'admin') {
//           navigate('/admindash');
//         } else if (Rolead === 'employee') {
          
//           navigate('/dashboard');
//         }
//       } else {
//         window.alert(response.data.message);
//       }
//     } catch (error) {
//       setMessage(error.response?.data?.message || 'An error occurred.');
//       alert("Unauthorized username or password");
//       console.error("Error:", error);
//     }
//   };

  // useEffect(() => {
  //   document.body.style.backgroundColor = '#e6f1fc';
  //   document.body.style.width = '100%';
  //   document.body.style.height = '100%';
  //   document.body.style.overflow = 'none';
  //   document.body.style.fontFamily = 'Inter, sans-serif';
  //   return () => {
  //     document.body.style.backgroundColor = '#e6f1fc';
  //   };
  // }, []);

//   return (
//     <div style={{ body: "#f9f9f9" }}>
//       <div className="lion" style={{ backgroundColor: "#e6f1fc" }}>
//         <header className='imageadd'>
//           <img src={Signlogo} height="100px" width="400px" alt="" />
//         </header>
//         <div className="cta-form"></div>
//         <div className='tec'>
//           <form className='frame' onSubmit={login}>
//             <center><h2>LOGIN IN NOW</h2></center>
//             <p><span className='ciju'> Use the form below to create your account.</span></p>
//             <br></br>
//             <input
//               type="text"
//               placeholder="Business Email"
//               autoComplete="off"
//               required
//               onChange={(e) => { setBusinessEmail(e.target.value) }}
//               className="input"
//               id="businessemail"
//             />
//             <br></br>
//             <input
//               type="password"
//               placeholder="Password"
//               required
//               autoComplete="off"
//               onChange={(e) => { setPassword(e.target.value) }}
//               className="input"
//               id="password"
//             />
//             <br></br>
//             <select
//               placeholder="Role"
//               style={{ marginBottom: "30px", height: "50px", width: "400px", borderColor: "#e6f1fc", backgroundColor: "#b5d3d7", borderRadius: "10px" }}
//               autoComplete="off"
//               value={Rolead}
//               onChange={(e) => { setRoleAd(e.target.value) }}
//               className="input"
//               id="role"
//             >
//               <option value="">Select Role</option>
//               <option value="admin">Admin</option>
//               <option value="employee">Employee</option>
//             </select>
//             <Link className='b1' to="/sign">Signup</Link>
//             <button type="submit" className='b2'>Login</button>
//           </form>
//         </div>
//         <br></br>
//       </div>
//     </div>
//   );
// }

// export default Login;



// JWT authendication
// import React, { useState, useEffect } from 'react';
// import './login.css';
// import Signlogo from './assets/company.png';
// import { Link, useNavigate } from 'react-router-dom';
// import Axios from 'axios';

// function Login() {
//   const [emp_email, setBusinessEmail] = useState('');
//   const [password, setPassword] = useState(''); 
//   const [Rolead, setRoleAd] = useState(''); 
//   const [message, setMessage] = useState('');
//   const [token, setToken] = useState('');
//   const navigate = useNavigate();

//   useEffect(() => {
//     window.history.pushState(null, '', window.location.href);
//     window.onpopstate = function (_event) {
//       window.history.pushState(null, '', window.location.href);
//     };

//     window.onbeforeunload = function () {
//       return "Are you sure you want to leave?";
//     };
//   }, []);

//   const login = async (e) => {
//     e.preventDefault();
  
//     const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
//     if (!emailRegex.test(emp_email)) {
//       window.alert("Please enter a valid Email Address.");
//       return;
//     } 
//     const minPasswordLength = 8;
//     const passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).{8,}$/;
//     if (!passwordRegex.test(password) || password.length < minPasswordLength) {
//       window.alert("Please enter a valid password.");
//       return;
//     } 
//     try {
//       const response = await Axios.post("http://localhost:3015/server", {
//         emp_email: emp_email,
//         password: password, 
//         Rolead:Rolead
//       });
  
//       if (response.data.message) {
//         setToken(response.data.token);
//         window.alert("Account logged in successfully"); 
    
//         if (Rolead === 'admin') {
//           navigate('/admindash'); 
//         } else if(Rolead === 'employee') {
//           navigate('/dashboard');
//         } 
//         sessionStorage.setItem('userRole', Rolead);
//         const isLoggedIn = true;
//         sessionStorage.setItem('isLoggedIn', JSON.stringify(isLoggedIn)); 
//       }  
//     } catch (error) {
//       setMessage(error.response?.data?.message || 'An error occurred.');
//       alert("Unauthorized username or password");
//       console.error("Error:", error);
//     }
//   };  
//   useEffect(() => {
//     document.body.style.backgroundColor = '#e6f1fc';
//     document.body.style.width = '100%';
//     document.body.style.height = '100%';
//     document.body.style.overflow = 'none';
//     document.body.style.fontFamily = 'Inter, sans-serif';
//     return () => {
//       document.body.style.backgroundColor = '#e6f1fc';
//     };
//   }, []); 
//   return (
//     <div style={{ body: "#f9f9f9" }}>
      // <div className="lion" style={{ backgroundColor: "#e6f1fc" }}>
      //   <header className='imageadd'>
      //     <img src={Signlogo} height="100px" width="400px" alt="" />
      //   </header>
      //   <div class="cta-form"></div>
      //   <div className='tec'>
      //     <form className='frame' onSubmit={login}>
      //       <center><h2>LOGIN IN NOW</h2></center>
      //       <p><span className='ciju'> Use the form below to create your account.</span></p>
      //       <br></br>
      //       <input type="text"  
      //       placeholder="Business Email" autocomplete="off" required onChange={(e)=>{setBusinessEmail(e.target.value)}}  classname="input" id="businessemail" />
      //   <br></br>
        
      //   <input type="text"
      //        placeholder="Password" required autocomplete="off" onChange={(e)=>{setPassword(e.target.value)}} classname="input" id="password" />
      //    <br></br> 
      //     <select  
      //        placeholder="Password"  style={{marginBottom:"30px",height:"50px",width:"400px",borderColor:"#e6f1fc",backgroundColor:"#b5d3d7",borderRadius:"10px"}} autocomplete="off" value={Rolead}onChange={(e)=>{setRoleAd(e.target.value)}} classname="input"  id="password" >
      //             <option value="">select</option>  
      //             <option value="admin">admin</option>     
      //             <option value="employee">employee</option>   1  
      //        </select>
      //        {/* <input type='checkbox' className='input' style={{height:"20px", width:"20px",marginLeft:"10px"}}  /><span>you are admin only check-in </span> */}
      //       <Link className='b1' to="/sign">Signup</Link>
      //       <button type="submit" className='b2'>Login</button>
      //     </form>
      //   </div>
      //   <br></br>
      // </div>
//     </div>
//   );
// }

// export default Login;


//original code
//   import React, { useState,useEffect } from 'react'
//   import './login.css'
//   import Signlogo from './assets/company.png'
//   import { Link, useNavigate  } from 'react-router-dom'
//   import  Axios  from 'axios';
//     function Login() { 
//    const [emp_email,setBusinessEmail]=useState('');
//    const [password,setPassword]=useState('');
//    const [message, setMessage] = useState('');
//    const [loginStatus,setLoginStatus] =useState('');
//    const [token, setToken] = useState('');
//    const navigate = useNavigate(); 
//    useEffect(() => {
//     // Disable browser back button navigation
//     window.history.pushState(null, '', window.location.href);
//     window.onpopstate = function (_event) {
//       window.history.pushState(null, '', window.location.href);
//     };

//     // Show a confirmation message when leaving the page
//     window.onbeforeunload = function () {
//       return "Are you sure you want to leave?";
//     };
//   }, []);
//    const login = async(e) => {
//     e.preventDefault(); 
    
//     const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/; 
//   if (!emailRegex.test(emp_email)) {
//     window.alert("Please enter a valid Email Address.");
//     return;
//   }
//   const minPasswordLength = 8;  
//   const passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*]).{8,}$/; 

//   if (!passwordRegex.test(password) || password.length < minPasswordLength) {
//     window.alert("Please enter valid  password.");
//     return;
//   }
//   try { 
//    const response = await Axios.post("http://localhost:3015/server", 
//     {
//       emp_email: emp_email,
//       password: password
//     });  
//     if (response.data.message) {  
//       setLoginStatus(response.data.message)
//       setToken(response.data.token);
//       window.alert("Account logged successfully"); 
//       navigate('/dashboard'); 
//       const userRole = response.data.role;

//       if (userRole === 'admin') {
//         navigate('/admin-dashboard');
//       } else if (userRole === 'user') {
//         navigate('/user-dashboard');
//       }

//       sessionStorage.setItem('userRole', userRole);
//       const isLoggedIn = true;
//       sessionStorage.setItem('isLoggedIn', JSON.stringify(isLoggedIn));
      
//     } else {  
//       alert("Invalid username or password. Please try again")
//       const isLoggedIn = false;
//       sessionStorage.setItem('isLoggedIn', JSON.stringify(isLoggedIn));
      
//     }
//   } 
//   catch (error) {
//     setMessage(error.response?.data?.message || 'An error occurred.');
//     alert(" Unauthorized username or password")
//     console.error("Error:", error);  
//     return; 
//   }
//   }; 
//   function log()
// {
//   navigate('/dashboard')
// }  useEffect(() => { 
//     document.body.style.backgroundColor = '#e6f1fc';
//     document.body.style.width = '100%';
//     document.body.style.height = '100%';
//     document.body.style.overflow = 'none';
//     document.body.style.fontFamily='Inter,sans-serif'; 
//     return () => {
//         document.body.style.backgroundColor='#e6f1fc';
//     };
//   }, []); 
//     return (
//       <div style={{body:"#f9f9f9"}} >
//       <div className="lion" style={{backgroundColor:"#e6f1fc"}}>  
//          <header className='imageadd'>
//              <img src={Signlogo}   height="100px" width="400px"alt =""/>
//         </header>
//         <div class="cta-form"> 
//       </div>
//      <div className='tec'>
//       <form className='frame'>
//         <center><h2>LOGIN IN NOW</h2></center>
//         <p ><span className='ciju'> Use the form below to create your account.</span> </p>
//         <br></br>
//        <input type="text"  
//             placeholder="Business Email" autocomplete="off" required onChange={(e)=>{setBusinessEmail(e.target.value)}}  classname="input" id="businessemail" />
//         <br></br>
//         <br></br>
//         <input type="text"
//              placeholder="Password" required autocomplete="off" onChange={(e)=>{setPassword(e.target.value)}} classname="input" id="password" />
//         <br></br>
//         <Link className='b1' to ="/sign">Signup</Link>   
         
//          <button  onClick={log} className='b2'>Login</button>
//          </form> 
//          </div>
//          <br></br>
//       </div>
//       </div>
//     )
//   } 
//   export default Login




            