// import React, { useEffect, useState } from 'react';
// import { Route,   Navigate } from 'react-router-dom';
// import axios from 'axios';

// const ProtectedRoute = ({ component: Component, role, ...rest }) => {
//   const [userRole, setUserRole] = useState('');
//   const [isLoading, setIsLoading] = useState(true);

//   useEffect(() => {
//     const fetchUserRole = async () => {
//       try {
//         const response = await axios.get('http://localhost:3015/protect', {
//           headers: {
//             Authorization: `Bearer ${localStorage.getItem('token')}`
//           }
//         });
//         setUserRole(response.data.role);
//       } catch (error) {
//         console.error('Error fetching user role:', error);
//       } finally {
//         setIsLoading(false);
//       }
//     };

//     fetchUserRole();
//   }, []);

//   if (isLoading) return <div>Loading...</div>;

//   return (
//     <Route
//       {...rest}
//       render={(props) =>
//         userRole === role ? <Component {...props} /> : <Navigate to="/unauthorized" />
//       }
//     />
//   );
// };

// export default ProtectedRoute;









// ProtectedRoute component
import React, { useEffect, useState } from 'react';
import { Route, Navigate } from 'react-router-dom';
import axios from 'axios';

const ProtectedRoute = ({ component: Component, role, ...rest }) => {
  const [userRole, setUserRole] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchUserRole = async () => {
      try {
        const response = await axios.post('http://localhost:3015/protect', { Rolead: role }, {
          headers: {
            Authorization:`Bearer ${localStorage.getItem('token')}`
          }
        });
        setUserRole(response.data.role);
      } catch (error) {
        console.error('Error fetching user role:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchUserRole();
  }, [role]); // Include role as a dependency to fetch user role when role changes

  if (isLoading) return <div>Loading...</div>;

  return (
    <Route
      {...rest}
      element={
        userRole === role ? <Component /> : <Navigate to="/unauthorized" />
      }
    />
  );
};

export default ProtectedRoute;

 