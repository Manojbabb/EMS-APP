import React from 'react';

const Unauthorized = () => {
  return <h1>Unauthorized Access</h1>;
};

export default Unauthorized;
