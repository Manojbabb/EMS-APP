import React, {useState,useEffect}from 'react';
import GlobalStyle from '../component/GlobalStyle';
import Header from '../component/Header';
import QuickActions from '../component/QuickScan';
import DashboardContent from '../component/DashboardContent';
import Sidebar from '../components/Sidebar'
import Employee from '../component/employee';
import { Link } from 'react-router-dom';

function Dashboard()  {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isAdmin, setIsAdmin] = useState(); 
  const isAndroidDevice = () => {
    return /Android/i.test(navigator.userAgent);
  };

  // Function to toggle desktop mode
  const toggleDesktopMode = () => {
    const isDesktopMode = localStorage.getItem('isDesktopMode') === 'true';
    localStorage.setItem('isDesktopMode', !isDesktopMode);
    window.location.reload(); // Reload the page to apply changes
  };

  // Automatically set desktop mode for Android devices on component mount
  useEffect(() => {
    if (isAndroidDevice()) {
      localStorage.setItem('isDesktopMode', 'true');
      window.location.reload(); // Reload the page to apply changes
    }
  }, []);
 
  useEffect(() => { 
    document.body.style.backgroundColor = 'white'; 
    return () => {
        document.body.style.backgroundColor = null;
    };
}, []);

  return ( 
    <div style={{ overflow: "hidden"}}>
    <Sidebar isOpen={isSidebarOpen} setIsOpen={setIsSidebarOpen} /> 
      <div className={`main-content ${isSidebarOpen ? 'sidebar-open' : 'sidebar-closed'}`}>
      <div className="App">
      <GlobalStyle />
      
      <Header />
      {/* <button style={{borderColor:"black",color:"black",borderRadius:"20px",marginLeft:"20px"}} onClick={toggleDashboard}>
        {isAdmin ? 'Switch to Employee Dashboard' : 'Switch to Admin Dashboard'}  
      </button>  */}
      {/* <Link to='/adminDash'>clcik</Link> */}
      {isAdmin  ? <QuickActions />:<Employee /> } 
      <DashboardContent />
    </div>
      </div> 
    </div> 
  )
} 
export default Dashboard;
 