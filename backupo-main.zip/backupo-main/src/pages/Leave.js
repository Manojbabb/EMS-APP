import React, { useEffect, useState } from 'react';
import Sidebar from '../components/Sidebar';
import Axios from 'axios';
import { useNavigate } from 'react-router-dom';

function Leave() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [status, setStatus] = useState(""); 
  const [leave_type, setLeaveType] = useState("");
  const [employee_id, setEmployeeID] = useState("");
  const [start_date, setStart] = useState("");
  const [end_date, setEnd] = useState("");
  const [lev_reason, setLevReason] = useState("");
  const [lev_approve, setLevApprove] = useState("");

  const navigate = useNavigate(); 
  const validateInput = (regex, value, id, errorMessage) => {
    const inputField = document.getElementById(id);
    if (!regex.test(value)) {
        inputField.style.border = '1px solid red';
        alert(errorMessage);
        inputField.focus();
        return false;
    } else {
        inputField.style.border = '1px solid green'; 
        return true;
    }
};

const validateInput2 = (regex, value, id, errorMessage) => {
    const inputField = document.getElementById(id);
    if (!regex.test(value)) {
        inputField.style.border = '1px solid red';
        alert(errorMessage);
        inputField.focus();
        return false;
    } else {
        inputField.style.border = '1px solid green'; 
        return true;
    }
};

const validateSelectInput = (value, id, errorMessage) => {
    const inputField = document.getElementById(id);
    if (!value) {
        inputField.style.border = '1px solid red';
        alert(errorMessage);
        inputField.focus();
        return false;
    } else {
        inputField.style.border = '1px solid green';
        return true;
    }
};

const nameRegex = /^[a-zA-Z\s]+$/;
const employeeIdRegex = /^\d{4}$/; 
const dateRegex = /^\d{4}-\d{2}-\d{2}$/;  
 
const validations = [
    { regex: nameRegex, value: leave_type, id: 'leave_type', errorMessage: 'Select your leave type' },
    { regex: employeeIdRegex, value: employee_id, id: 'employee_id', errorMessage: 'Please enter a valid employee ID: it should be a 4-digit number' },
    { regex: dateRegex, value: start_date, id: 'start_date', errorMessage: 'Please enter a valid start date (YYYY-MM-DD)' },
    { regex: dateRegex, value: end_date, id: 'end_date', errorMessage: 'Please enter a valid end date (YYYY-MM-DD)' },
    { regex: nameRegex, value: lev_reason, id: 'lev_reason', errorMessage: 'Enter a leave reason' }
];

const send = async (e) => {
    e.preventDefault();

    for (const { regex, value, id, errorMessage } of validations) {
        if (!validateInput(regex, value, id, errorMessage)) return;
    }

    if (!validateSelectInput(leave_type, 'leave_type', 'Select your leave type')) return;
    if (!validateInput(employeeIdRegex, employee_id, 'employee_id', 'Please enter a valid employee ID: it should be a 4-digit number')) return;
    if (!validateInput(dateRegex, start_date, 'start_date', 'Please enter a valid start date (YYYY-MM-DD)')) return;
    if (!validateInput(dateRegex, end_date, 'end_date', 'Please enter a valid end date (YYYY-MM-DD)')) return;
    if (!validateInput(nameRegex, lev_reason, 'lev_reason', 'Enter a leave reason')) return;
    if (!validateInput2(nameRegex, lev_approve, 'lev_approve', 'Enter leave approver name')) return;

 
    
    // if (!employee_id) {
    //     alert(".");
    //     return;   
    // }

    // if (!start_date) {
    //     alert("Please select leave start date.");
    //     return;
    // }

    // if (!end_date) {
    //     alert("Please select leave end date.");
    //     return;
    // }

    // if (!lev_reason) {
    //     alert("Please enter leave reason.");
    //     return;
    // }

    // if (!lev_approve) {
    //     alert("Please enter leave approval.");
    //     return;
    // }

    // // Text validation
    // const textRegex = /^[a-zA-Z\s]+$/;
    // if (!textRegex.test(leave_type)) {
    //     alert("Please enter valid text for leave type.");
    //     return;
    // }

   
    // const idRegex = /^\d+$/;
    // if (!idRegex.test(employee_id)) {
    //     alert("Please enter a valid employee ID.");
    //     return;
    // }  
    // const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
    // if (!dateRegex.test(start_date) || !dateRegex.test(end_date)) {
    //     alert("Please enter dates in the format YYYY-MM-DD.");
    //     return;
    // } 
    // if (!textRegex.test(lev_reason)) {
    //     alert("Please enter valid text for leave reason.");
    //     return;
    // }

    // if (!textRegex.test(lev_approve)) {
    //     alert("Please enter valid text for leave approval.");
    //     return;
    // } 
    // const startDateObj = new Date(start_date);
    // const endDateObj = new Date(end_date);
    // if (endDateObj < startDateObj) {
    //     alert("End date should not be before start date.");
    //     return;
    // }

    try {
        // const response = await Axios.post('http://localhost:3015/unland', {
        const response = await Axios.post('http://192.168.1.151:3015/unland', {
            leave_type: leave_type,
            employee_id: employee_id,
            start_date: start_date,
            end_date: end_date,
            lev_reason: lev_reason,
            lev_approve: lev_approve,
        }); if(response.data[0]) {
                window.alert("Account created successfully");
                navigate('/leaveinfo');
                return;
            } 
             else {
                setStatus(response.data)
                window.alert("Your account has already been created."); 
                return; 
          }
        }
             catch (error) {
              console.error('Error creating account:', error);
              alert("An error occurred, please try again later");
            }
          }; 
          useEffect(() => { 
            document.body.style.backgroundColor = 'white'; 
            return () => {
                document.body.style.backgroundColor = null;
            };
        }, []);
  return (
    <div>
      <Sidebar isOpen={isSidebarOpen} setIsOpen={setIsSidebarOpen} />

      <div className={`main-content ${isSidebarOpen ? 'sidebar-open' : 'sidebar-closed'}`}>
        <form className="leave-form">
        <h2  style={{marginLeft:"160px",color:"#6ca2ac"}}>Leave Form</h2>
        {/* <label htmlFor="approver">Leave type by</label>
          <input type="text" placeholder="Enter your leave approver name"   required onChange={(e) => setLevApprove(e.target.value)} id="approver" className="collect" /> */}
<div className='form-group'>
<label style={{width:"90px"}} htmlFor="employee-id">Leave type</label>
<select  style={{marginLeft:"60px"}}id='leave_type' required onChange={(e) => setLeaveType(e.target.value)} className="collect">

         <option   value="">Select leave</option>
         <option   value="Sick leave">Sick leave</option>
         <option   value='Casual leave'>Casual leave</option>
         <option   value='Paid leave'>Paid leave</option>
         </select> </div><div className='form-group'>
          <label  style={{marginLeft:"30px"}}htmlFor="employee-id">Employee ID</label>
          <input style={{marginLeft:"50px"}} id='employee_id'  required type="text" placeholder="Enter your ID"     onChange={(e) => setEmployeeID(e.target.value)}   className="collect" />
          </div><div className='form-group'>
          <label  style={{width:"100px",fontWeight:"none"}}htmlFor="start-date">Leave start date</label>
          <input style={{marginLeft:"50px"}} type="date" id='start_date'  onChange={(e) => setStart(e.target.value)} required   className="collect" />
          </div><div className='form-group'>
          <label  style={{width:"90px"}}htmlFor="end-date">Leave end date</label>
          <input style={{marginLeft:"60px"}} type="date" id ='end_date'onChange={(e) => setEnd(e.target.value)} required  className="collect" />
          </div><div className='form-group'>
          <label  style={{width:"120px"}}htmlFor="leave-reason">Leave Reason</label>
          <input style={{marginLeft:"30px"}} type="text" id='lev_reason' placeholder="Enter leave reason" required   onChange={(e) => setLevReason(e.target.value)}  className="collect" />
          </div><div className='form-group'>
          <label  style={{width:"140px"}}htmlFor="approver">Leave Approved by</label>
          <input style={{marginLeft:"10px"}} type="text" id='lev_approve' placeholder="Enter leave approver name"   required onChange={(e) => setLevApprove(e.target.value)}   className="collect" />
          </div> 
          <button type="submit" onClick={send} style={{marginLeft:"147px",marginTop:"20px"}}className='button-27'>Submit</button>
        </form>
      </div>
    </div>
  );
}

export default Leave;





























